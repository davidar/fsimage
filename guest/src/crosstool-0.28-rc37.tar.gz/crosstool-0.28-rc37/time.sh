time sh demo.sh
